import asyncio
import datetime
from bleak import BleakClient, BleakScanner
ESP32_TARGET_MAC = "XX:XX:XX:XX:XX:XX" 
SERVICE_UUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
CHARACTERISTIC_UUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8"
LOG_FILE = "basketball_practice_log.txt"
async def on_shot_received(sender, data):
    shot_data = data.decode('utf-8')
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted_message = f"[{timestamp}] Court-Side Shot Detected: {shot_data}"
    print(formatted_message)
    try:
        with open(LOG_FILE, "a") as f:
            f.write(formatted_message + "\n")
    except Exception as e:
        print(f"Logging error: {e}")
async def main():
    print("Basketball Kinematic Tracker - Passive Python Backend")
    print("-" * 50)
    print(f"Scanning for ESP32 sleeve ({ESP32_TARGET_MAC})...")
    try:
        async with BleakClient(ESP32_TARGET_MAC) as client:
            print(f"-> Connected!")
            print(f"-> Subscribing to Characteristic: {CHARACTERISTIC_UUID}")
            await client.start_notify(CHARACTERISTIC_UUID, on_shot_received)
            print("Listening for shots...")
            await asyncio.sleep(7200) 
            await client.stop_notify(CHARACTERISTIC_UUID)
            print("Analytics session ended.")
    except Exception as e:
        print(f"BLE Connection failed: {e}")
if __name__ == "__main__":
    asyncio.run(main())