#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <math.h>
#define I2C_SDA 8
#define I2C_SCL 9
#define SERVICE_UUID "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"
const int hapticPin = 3; 
const float SHOT_ACCEL_THRESHOLD = 3.5;
const float FLICK_GYRO_THRESHOLD = 450.0;
Adafruit_MPU6050 mpu;
BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;
unsigned long shotStartTime = 0;
bool isShooting = false;
int flickCheckWindow_ms = 220;
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) { deviceConnected = true; };
    void onDisconnect(BLEServer* pServer) { deviceConnected = false; }
};
void setup() {
  Serial.begin(115200);
  pinMode(hapticPin, OUTPUT);
  digitalWrite(hapticPin, LOW);
  Wire.begin(I2C_SDA, I2C_SCL); 
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip!");
    while (1) { delay(10); }
  }
  Serial.println("MPU6050 Found!");
  mpu.setAccelerometerRange(MPU6050_RANGE_16_G);
  mpu.setGyroRange(MPU6050_RANGE_2000_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_44_HZ);
  BLEDevice::init("ShootersTouch_Sleeve");
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  BLEService *pService = pServer->createService(SERVICE_UUID);
  pCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  pCharacteristic->addDescriptor(new BLE2902());
  pService->start();
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);
  pAdvertising->setMaxPreferred(0x12);
  BLEDevice::startAdvertising();
  Serial.println("BLE Ready to Pair!");
}
void loop() {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    float accelX = a.acceleration.x;
    float accelY = a.acceleration.y;
    float accelZ = a.acceleration.z;
    float totalAccel = sqrt((accelX * accelX) + (accelY * accelY) + (accelZ * accelZ));
    float wristFlickRotation = abs(g.gyro.x);
    if (!isShooting && totalAccel > SHOT_ACCEL_THRESHOLD) {
        isShooting = true;
        shotStartTime = millis();
        Serial.println("[SHOT DETECTED]");
    }
    if (isShooting) {
        if (wristFlickRotation > FLICK_GYRO_THRESHOLD) {
            Serial.println("-> Kinematics GOOD (Flick Detected)");
            triggerHaptic(50, 20);
            delay(10);
            triggerHaptic(50, 0);
            if (deviceConnected) {
                pCharacteristic->setValue("SHOT:GOOD");
                pCharacteristic->notify();
            }
            isShooting = false;
        } else if (millis() - shotStartTime > flickCheckWindow_ms) {
            Serial.println("-> SHORT-ARMED! Triggering Haptics.");
            triggerHaptic(180, 0); 
            if (deviceConnected) {
                pCharacteristic->setValue("SHOT:SHORT");
                pCharacteristic->notify();
            }
            isShooting = false;
        }
    }
    if (!deviceConnected && oldDeviceConnected) {
        delay(500);
        pServer->startAdvertising();
        Serial.println("Advertising restarted.");
        oldDeviceConnected = deviceConnected;
    }
    if (deviceConnected && !oldDeviceConnected) {
        oldDeviceConnected = deviceConnected;
    }
    delay(10); 
}
void triggerHaptic(int duration_ms, int delay_ms) {
    digitalWrite(hapticPin, HIGH);
    delay(duration_ms);
    digitalWrite(hapticPin, LOW);
    if (delay_ms > 0) {
        delay(delay_ms);
    }
}