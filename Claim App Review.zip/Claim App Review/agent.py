import os
import json
import base64
import logging
import pandas as pd
from pathlib import Path
from io import BytesIO
from PIL import Image
from huggingface_hub import hf_hub_download
from llama_cpp import Llama

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

model_path = hf_hub_download(
    repo_id="unsloth/gemma-3-12b-it-qat-GGUF",
    filename="gemma-3-12b-it-qat-UD-Q4_K_XL.gguf"
)

llm = Llama(
    model_path=model_path,
    n_gpu_layers=-1,
    n_ctx=4096
)

def load_datasets(base_dir="dataset"):
    history = pd.read_csv(os.path.join(base_dir, "user_history.csv"))
    evidence = pd.read_csv(os.path.join(base_dir, "evidence_requirements.csv"))
    return history, evidence

def get_user_history_context(user_id, df):
    row = df[df["user_id"] == user_id]
    if row.empty:
        return "No history available"
    r = row.iloc[0]
    return f"Past claims: {r['past_claim_count']}, Accepted: {r['accept_claim']}, Rejected: {r['rejected_claim']}"

def get_evidence_requirements(obj, df):
    rows = df[(df["claim_object"] == obj) | (df["claim_object"] == "all")]
    return "\n".join(rows["minimum_image_evidence"].astype(str).tolist())

def process_image_to_base64(path, base, max_size=(512, 512)):
    file = Path(base) / path
    if not file.exists():
        return None
    
    try:
        with Image.open(file) as img:
            if img.mode != 'RGB':
                img = img.convert('RGB')
            img.thumbnail(max_size, Image.Resampling.LANCZOS)
            buffer = BytesIO()
            img.save(buffer, format="JPEG", quality=85)
            data = base64.b64encode(buffer.getvalue()).decode("utf-8")
        return f"data:image/jpeg;base64,{data}"
    except Exception as e:
        log.error(e)
        return None

def analyze_claim(claim, history, evidence, images_base_dir=".", max_retries=1):
    images = [x.strip() for x in str(claim.get("image_paths", "")).split(";") if x.strip()]
    
    prompt = f"""
    You are an insurance claim reviewer. Return ONLY valid JSON.
    Object: {claim.get('claim_object', 'Unknown')}
    Claim: {claim.get('user_claim', 'Unknown')}
    History: {get_user_history_context(claim.get('user_id'), history)}
    Evidence rules: {get_evidence_requirements(claim.get('claim_object'), evidence)}
    Image paths provided: {claim.get('image_paths', 'none')}
    
    Ensure your JSON strictly uses these exact categories:
    - "claim_status": ["supported", "contradicted", "not_enough_information"]
    - "severity": ["low", "medium", "high", "none", "unknown"]
    - "issue_type": ["dent", "scratch", "crack", "broken_part", "stain", "crushed_packaging", "torn_packaging", "water_damage", "none", "unknown"]
    - "object_part": ["rear_bumper", "front_bumper", "windshield", "side_mirror", "headlight", "door", "screen", "hinge", "keyboard", "corner", "trackpad", "package_corner", "seal", "package_side", "contents", "unknown"]
    - "risk_flags": Use "none" OR semicolon-separated values from: ["claim_mismatch", "user_history_risk", "manual_review_required", "wrong_angle", "damage_not_visible", "blurry_image", "non_original_image", "cropped_or_obstructed", "wrong_object", "text_instruction_present"].
    - "supporting_image_ids": Extract the base filename without extension from the Image paths provided (e.g., "img_1"). If multiple support the claim, separate with semicolons (e.g., "img_1;img_2"). If none, use "none".
    
    {{
    "evidence_standard_met": true,
    "evidence_standard_met_reason": "string",
    "risk_flags": "string",
    "issue_type": "string",
    "object_part": "string",
    "claim_status": "string",
    "claim_status_justification": "string",
    "supporting_image_ids": "string",
    "valid_image": true,
    "severity": "string"
    }}
    """
    
    content = [{"type": "text", "text": prompt}]
    
    for img in images:
        encoded_img = process_image_to_base64(img, images_base_dir)
        if encoded_img:
            content.append({
                "type": "image_url", 
                "image_url": {"url": encoded_img}
            })
            
    try:
        response = llm.create_chat_completion(
            messages=[{"role": "user", "content": content}],
            temperature=0.0,
            max_tokens=1000,
            response_format={"type": "json_object"}
        )
        result = json.loads(response["choices"][0]["message"]["content"])
        result["_images_found"] = len(images)
        return result
    except Exception as e:
        err_msg = str(e)
        log.error(f"Local Inference failed: {err_msg}")
        return fallback(err_msg)

def fallback(error):
    return {
        "evidence_standard_met": False,
        "evidence_standard_met_reason": str(error),
        "risk_flags": "manual_review_required",
        "issue_type": "unknown",
        "object_part": "unknown",
        "claim_status": "not_enough_information",
        "claim_status_justification": str(error),
        "supporting_image_ids": "none",
        "valid_image": False,
        "severity": "unknown",
        "_images_found": 0
    }

def process_claims_csv(input_csv, output_csv, images_base_dir=".", base_dir="dataset", delay_between=0, progress_callback=None):
    claims = pd.read_csv(input_csv)
    history, evidence = load_datasets(base_dir)
    results = []
    total = len(claims)
    
    for i, row in claims.iterrows():
        if progress_callback:
            progress_callback(i, total, row.get("user_id", "Unknown"))
        result = analyze_claim(row, history, evidence, images_base_dir)
        results.append({**row.to_dict(), **result})
        
    pd.DataFrame(results).to_csv(output_csv, index=False)
    return {"total_claims": total, "processed": len(results), "output_file": output_csv}