import os
import sys
import time
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from agent import process_claims_csv, load_datasets
from evaluator import evaluate_predictions, generate_evaluation_report


def print_progress(idx, total, user_id):
    pct = int(((idx + 1) / total) * 100)
    bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
    print(f"\r[{bar}] {pct}% | {idx+1}/{total} | {user_id}", end="", flush=True)


def main():
    parser = argparse.ArgumentParser(description="Multi-Modal Evidence Review CLI")
    parser.add_argument("--mode", choices=["test", "sample", "both"], default="both",
                        help="Which dataset to process")
    parser.add_argument("--dataset-dir", default="dataset", help="Path to dataset directory")
    parser.add_argument("--images-dir", default="dataset", help="Base directory for images")
    parser.add_argument("--output-dir", default=".", help="Directory to write output files")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between API calls (seconds)")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs("evaluation", exist_ok=True)

    if not os.environ.get("GOOGLE_API_KEY"):
        print("ERROR: GOOGLE_API_KEY environment variable not set.")
        sys.exit(1)

    start = time.time()
    total_stats = {"sample_input_tokens": 0, "sample_output_tokens": 0, "sample_images": 0,
                   "test_input_tokens": 0, "test_output_tokens": 0, "test_images": 0}

    if args.mode in ("sample", "both"):
        print("\n=== Processing SAMPLE claims (evaluation mode) ===")
        sample_csv = os.path.join(args.dataset_dir, "sample_claims.csv")
        sample_output = os.path.join(args.output_dir, "sample_predictions.csv")

        stats = process_claims_csv(
            input_csv=sample_csv,
            output_csv=sample_output,
            images_base_dir=args.images_dir,
            base_dir=args.dataset_dir,
            delay_between=args.delay,
            progress_callback=print_progress
        )
        print(f"\n✓ Sample predictions written to: {sample_output}")

        total_stats["sample_input_tokens"] = stats["total_input_tokens"]
        total_stats["sample_output_tokens"] = stats["total_output_tokens"]
        total_stats["sample_images"] = stats["total_images"]

        print("\n=== Evaluating sample predictions ===")
        eval_results = evaluate_predictions(sample_csv, sample_output)
        print(f"\nOverall Score: {eval_results['overall_score']}")
        print("\nPer-field breakdown:")
        for field, data in eval_results["per_field"].items():
            if "accuracy" in data:
                print(f"  {field:35s}: {data['accuracy']:.3f} accuracy ({data['correct']}/{data['total']})")
            else:
                print(f"  {field:35s}: {data.get('avg_f1', 'N/A'):.3f} avg F1")

        report_path = os.path.join("evaluation", "evaluation_report.md")
        generate_evaluation_report(eval_results, total_stats, report_path)
        print(f"\n✓ Evaluation report written to: {report_path}")

    if args.mode in ("test", "both"):
        print("\n=== Processing TEST claims (final output) ===")
        test_csv = os.path.join(args.dataset_dir, "claims.csv")
        test_output = os.path.join(args.output_dir, "output.csv")

        stats = process_claims_csv(
            input_csv=test_csv,
            output_csv=test_output,
            images_base_dir=args.images_dir,
            base_dir=args.dataset_dir,
            delay_between=args.delay,
            progress_callback=print_progress
        )
        print(f"\n✓ Final output written to: {test_output}")

        total_stats["test_input_tokens"] = stats["total_input_tokens"]
        total_stats["test_output_tokens"] = stats["total_output_tokens"]
        total_stats["test_images"] = stats["total_images"]

    elapsed = time.time() - start
    total_stats["runtime_seconds"] = round(elapsed, 1)
    total_stats["total_images"] = total_stats["sample_images"] + total_stats["test_images"]

    total_in = total_stats["sample_input_tokens"] + total_stats["test_input_tokens"]
    total_out = total_stats["sample_output_tokens"] + total_stats["test_output_tokens"]
    cost = (total_in / 1_000_000 * 1.25) + (total_out / 1_000_000 * 10.0)
    total_stats["estimated_cost_usd"] = round(cost, 4)

    print("\n=== Run Summary ===")
    print(f"  Runtime     : {elapsed:.1f}s")
    print(f"  Input tokens: {total_in:,}")
    print(f"  Output tokens:{total_out:,}")
    print(f"  Images      : {total_stats['total_images']}")
    print(f"  Est. cost   : ${cost:.4f}")

    if args.mode in ("sample", "both"):
        report_path = os.path.join("evaluation", "evaluation_report.md")
        generate_evaluation_report(eval_results, total_stats, report_path)
        print(f"\n✓ Final evaluation report updated: {report_path}")

    print("\n✅ Done!")


if __name__ == "__main__":
    main()
