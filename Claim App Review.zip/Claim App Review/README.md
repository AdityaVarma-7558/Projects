# 🛡️ ClaimIntel: Local AI Insurance Review Pipeline

ClaimIntel is a self-hosted, multi-modal AI web application designed to automatically
process, analyze, and validate insurance claims. By utilizing a local Vision-Language
Model (VLM), the system evaluates customer claims against submitted evidence photos
and historical data, outputting strict, structurally validated JSON for automated
decision-making.

## 🚀 Recent Updates & Architecture Shift

This project has been heavily updated for production-grade local execution, eliminating
previous cloud dependencies:

- **Local Inference Engine:** Migrated from Groq/Mistral cloud APIs to local execution
  using `llama-cpp-python` and Hugging Face.
- **Model Upgrade:** Now powered by `unsloth/gemma-3-12b-it-qat-GGUF` (4-bit
  Quantization-Aware Training) for optimal balance of high-end reasoning and low
  hardware consumption.
- **UI Overhaul:** Rebuilt the Flask frontend with a responsive, modern Dark Theme
  using Tailwind CSS.
- **Strict Evaluation Protocol:** Updated prompt engineering to enforce strict JSON
  Enum categorization, ensuring 100% compatibility with automated `evaluator.py`
  F1-score calculations.
- **Zero Rate Limits:** Removed artificial thread delays; batch processing now runs
  continuously at maximum local hardware capacity.

---

## 💻 Hardware Requirements

Because this application runs a 12-Billion parameter neural network locally, your
machine must meet the following specifications:

- **System RAM:** Minimum 16 GB (32 GB recommended).
- **GPU VRAM (Optional but highly recommended):** 8 GB+ (e.g., RTX 3060, 4070,
  or Mac M-Series Unified Memory).
- **Storage:** ~10 GB of free space for downloading the GGUF model weights.

---

## 🛠️ Installation & Setup

### 1. Environment Preparation

Ensure you have Python 3.10+ installed. Create a virtual environment:

```bash
python -m venv venv

# On Windows:
venv\Scripts\activate

# On Mac/Linux:
source venv/bin/activate
```

### 2. Windows C++ Build Tools (Crucial for Windows Users)

Because the `llama-cpp-python` inference engine compiles C++ locally, Windows users
must have the Microsoft C++ compiler installed:

1. Download **Visual Studio Build Tools**.
2. Run the installer and select **"Desktop development with C++"**.
3. Finish the installation and restart your terminal.

> **Note:** If you have an NVIDIA GPU, you can bypass manual compilation by using
> the pre-built CUDA wheels. See the `llama-cpp-python` documentation for the exact
> `--extra-index-url` command.

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## 📂 Project Structure
├── dataset/

│   ├── user_history.csv            # Historical claim profiles

│   ├── evidence_requirements.csv   # Validation rules per object

│   └── sample_claims.csv           # Test batch data

├── evaluation/                     # Auto-generated markdown reports

├── output/                         # Processed AI JSON results (.csv)

├── templates/

│   └── index.html                  # Dark-mode Tailwind dashboard

├── agent.py                        # Local LLM initialization and inference logic

├── app.py                          # Flask web server and threading

├── evaluator.py                    # F1/Accuracy metric calculations

└── README.md
---

## 🏃 Running the Pipeline

**1. Start the Server:**

```bash
python app.py
```

> **Note:** The first time you run this, `agent.py` will automatically download the
> ~8 GB Gemma-3 model from Hugging Face. Subsequent runs will load it instantly
> from your local cache.

**2. Access the Dashboard:**
Open your browser and navigate to `http://localhost:5000`.

**3. Execute a Batch:**
Click **"Evaluate Sample Set"** on the dashboard. The local AI will begin processing
the claims. You can monitor the live progress bar, and upon completion, download the
resulting output CSV or view the generated evaluation report in the `evaluation/`
directory.

---

## 📊 Evaluation & Metrics

The pipeline uses a rigid schema to grade the AI's performance against human baseline
files. The `evaluator.py` script automatically calculates:

- **Exact-match Accuracy** for strict categorizations (e.g., `issue_type`, `severity`).
- **Intersection F1-Scores** for multi-select arrays
  (e.g., `supporting_image_ids`, `risk_flags`).