import os
import time
import uuid
import threading
import logging
from pathlib import Path
import pandas as pd
from flask import Flask, render_template, request, jsonify, send_file
from agent import process_claims_csv, analyze_claim, load_datasets
from evaluator import evaluate_predictions, generate_evaluation_report

app = Flask(__name__)

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
EVAL_DIR = os.path.join(BASE_DIR, "evaluation")
IMAGES_DIR = DATASET_DIR

Path(OUTPUT_DIR).mkdir(exist_ok=True)
Path(EVAL_DIR).mkdir(exist_ok=True)

jobs = {}
metrics = {
    "processed_claims": 0,
    "active_jobs": 0,
    "system_status": "ONLINE"
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/dashboard")
def dashboard():
    return jsonify({
        "metrics": metrics,
        "jobs": list(jobs.values())[-10:]
    })

@app.route("/api/claims/list")
def claims_list():
    mode = request.args.get("mode", "test")
    filename = "sample_claims.csv" if mode == "sample" else "claims.csv"
    path = os.path.join(DATASET_DIR, filename)
    
    if not os.path.exists(path):
        return jsonify({"total": 0, "claims": []})
        
    df = pd.read_csv(path)
    return jsonify({"total": len(df), "claims": df.to_dict(orient="records")})

@app.route("/api/claims/analyze", methods=["POST"])
def analyze_single():
    data = request.json
    history, evidence = load_datasets(DATASET_DIR)
    
    claim = {
        "user_id": data.get("user_id"),
        "image_paths": data.get("image_paths"),
        "user_claim": data.get("user_claim"),
        "claim_object": data.get("claim_object")
    }
    
    result = analyze_claim(claim, history, evidence, IMAGES_DIR)
    result.pop("_images_found", None)
    
    return jsonify({"claim": claim, "result": result})

@app.route("/api/run", methods=["POST"])
def run_pipeline():
    data = request.json or {}
    mode = data.get("mode", "test")
    job_id = str(uuid.uuid4())[:8]
    
    input_file = os.path.join(DATASET_DIR, "sample_claims.csv" if mode == "sample" else "claims.csv")
    output_file = os.path.join(OUTPUT_DIR, f"{job_id}_{mode}_results.csv")
    
    if not os.path.exists(input_file):
        return jsonify({"error": f"File not found: {input_file}"}), 404
        
    total = len(pd.read_csv(input_file))
    
    jobs[job_id] = {
        "id": job_id,
        "mode": mode.upper(),
        "status": "RUNNING",
        "progress": 0,
        "total": total,
        "current": "Initializing...",
        "output": None
    }
    
    metrics["active_jobs"] += 1

    def worker():
        def update(index, total_claims, user):
            jobs[job_id]["progress"] = index + 1
            jobs[job_id]["total"] = total_claims
            jobs[job_id]["current"] = user

        try:
            result = process_claims_csv(
                input_csv=input_file,
                output_csv=output_file,
                images_base_dir=IMAGES_DIR,
                base_dir=DATASET_DIR,
                delay_between=0,
                progress_callback=update
            )
            
            jobs[job_id].update({
                "status": "COMPLETED",
                "output": output_file,
                "stats": result,
                "current": "Done"
            })
            
            metrics["processed_claims"] += total

            if mode == "sample":
                evaluation = evaluate_predictions(input_file, output_file)
                report = os.path.join(EVAL_DIR, f"{job_id}.md")
                generate_evaluation_report(evaluation, result, report)
                jobs[job_id]["report"] = report

        except Exception as e:
            logging.exception(e)
            jobs[job_id].update({"status": "FAILED", "error": str(e), "current": "Error occurred"})
        finally:
            metrics["active_jobs"] -= 1

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"job_id": job_id, "status": "started", "total": total})

@app.route("/api/run/status/<job_id>")
def job_status(job_id):
    return jsonify(jobs.get(job_id, {"error": "not found"}))

@app.route("/api/download/<job_id>")
def download(job_id):
    job = jobs.get(job_id)
    if not job or not job.get("output"):
        return jsonify({"error": "not ready"}), 404
    return send_file(job["output"], as_attachment=True, download_name=f"results_{job_id}.csv")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)