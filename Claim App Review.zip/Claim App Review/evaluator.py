import pandas as pd
import json
from pathlib import Path
from datetime import datetime

EXACT_MATCH_COLS = ["claim_status", "issue_type", "object_part", "severity", "evidence_standard_met", "valid_image"]

def parse_flags(flag_str):
    if pd.isna(flag_str) or str(flag_str).strip().lower() == "none":
        return set()
    return set(f.strip() for f in str(flag_str).split(";") if f.strip())

def parse_image_ids(id_str):
    if pd.isna(id_str) or str(id_str).strip().lower() == "none":
        return set()
    return set(f.strip() for f in str(id_str).split(";") if f.strip())

def evaluate_predictions(sample_csv, predictions_csv):
    sample_df = pd.read_csv(sample_csv)
    pred_df = pd.read_csv(predictions_csv)
    
    report = {
        "total_samples": len(sample_df),
        "predictions_found": int(pred_df.shape[0]),
        "per_field": {},
        "per_case": []
    }
    
    exact_scores = {col: [] for col in EXACT_MATCH_COLS}
    flag_f1s = []
    img_id_f1s = []
    
    for _, row in sample_df.iterrows():
        uid = row["user_id"]
        img = row["image_paths"]
        
        pred_rows = pred_df[(pred_df["user_id"] == uid) & (pred_df["image_paths"] == img)]
        if pred_rows.empty:
            report["per_case"].append({"user_id": uid, "matched": False})
            continue
            
        pred = pred_rows.iloc[0]
        case_result = {"user_id": uid, "matched": True, "fields": {}}
        
        for col in EXACT_MATCH_COLS:
            gt_val = str(row.get(col, "")).strip().lower()
            pred_val = str(pred.get(col, "")).strip().lower()
            match = gt_val == pred_val
            exact_scores[col].append(match)
            case_result["fields"][col] = {"gt": gt_val, "pred": pred_val, "match": match}
            
        gt_flags = parse_flags(row.get("risk_flags", "none"))
        pred_flags = parse_flags(pred.get("risk_flags", "none"))
        flag_f1 = compute_f1(gt_flags, pred_flags)
        flag_f1s.append(flag_f1)
        
        gt_imgs = parse_image_ids(row.get("supporting_image_ids", "none"))
        pred_imgs = parse_image_ids(pred.get("supporting_image_ids", "none"))
        img_f1 = compute_f1(gt_imgs, pred_imgs)
        img_id_f1s.append(img_f1)
        
        report["per_case"].append(case_result)
        
    for col in EXACT_MATCH_COLS:
        scores = exact_scores[col]
        if scores:
            report["per_field"][col] = {
                "accuracy": round(sum(scores) / len(scores), 3),
                "correct": sum(scores),
                "total": len(scores)
            }
            
    report["per_field"]["risk_flags"] = {"avg_f1": round(sum(flag_f1s) / len(flag_f1s), 3) if flag_f1s else 0.0}
    report["per_field"]["supporting_image_ids"] = {"avg_f1": round(sum(img_id_f1s) / len(img_id_f1s), 3) if img_id_f1s else 0.0}
    
    overall_scores = [report["per_field"][col]["accuracy"] for col in EXACT_MATCH_COLS if col in report["per_field"]]
    if flag_f1s: overall_scores.append(sum(flag_f1s) / len(flag_f1s))
    if img_id_f1s: overall_scores.append(sum(img_id_f1s) / len(img_id_f1s))
    
    report["overall_score"] = round(sum(overall_scores) / len(overall_scores), 3) if overall_scores else 0.0
    return report

def compute_f1(gt_set, pred_set):
    if not gt_set and not pred_set: return 1.0
    if not gt_set or not pred_set: return 0.0
    intersection = gt_set & pred_set
    precision = len(intersection) / len(pred_set)
    recall = len(intersection) / len(gt_set)
    if precision + recall == 0: return 0.0
    return 2 * precision * recall / (precision + recall)

def generate_evaluation_report(eval_results, stats, output_path="evaluation/evaluation_report.md"):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# Multi-Modal Evidence Review — Evaluation Report",
        f"\n_Generated: {now}_\n",
        "## 1. Accuracy Summary\n",
        f"- **Overall Score**: {eval_results['overall_score']}",
        f"- **Total Sample Cases**: {eval_results['total_samples']}",
        f"- **Predictions Matched**: {eval_results['predictions_found']}",
        "\n### Per-Field Results\n",
        "| Field | Score | Type |",
        "|-------|-------|------|"
    ]
    
    for field, data in eval_results["per_field"].items():
        if "accuracy" in data:
            lines.append(f"| {field} | {data['accuracy']} ({data['correct']}/{data['total']}) | Accuracy |")
        else:
            lines.append(f"| {field} | {data.get('avg_f1', 'N/A')} | Avg F1 |")
            
    lines += [
        "\n## 2. Operational Analysis\n",
        "### System Info",
        "- Engine: Local Gemma-3-12B-QAT",
        f"- Processed: {stats.get('processed', 'N/A')} claims"
    ]
    
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        f.write("\n".join(lines))
    return output_path