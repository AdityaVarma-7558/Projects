#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// --- SPI OLED PIN CONFIGURATION ---
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// These match your exact wiring blueprint
#define OLED_MOSI  D2    // Connects to D1 on OLED
#define OLED_CLK   D1    // Connects to D0 on OLED
#define OLED_DC    D3    // Connects to DC on OLED
#define OLED_CS    D4    // Connects to CS on OLED
#define OLED_RESET D0    // Connects to RES on OLED

// Initialize the SPI display using Software SPI
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, OLED_MOSI, OLED_CLK, OLED_DC, OLED_RESET, OLED_CS);

// --- HARDWARE PIN CONFIGURATION (NodeMCU ESP-12E) ---
const int irSensorPin = D5;
const int ledPin = D6;
const int buzzerPin = D7;

const unsigned long drowsyLimitMs = 2000; // 2 seconds limit before alarm triggers
unsigned long sleepTimerStart = 0;

// Variables to track state and prevent screen flickering
bool isAlarmOn = false;
int lastDisplayState = -1; // -1 = Bootup, 0 = Awake, 1 = Asleep

void setup() {
    Serial.begin(115200);
    
    pinMode(irSensorPin, INPUT);
    pinMode(buzzerPin, OUTPUT);
    pinMode(ledPin, OUTPUT);

    // Initialize the SPI OLED Screen
    if (!display.begin(SSD1306_SWITCHCAPVCC)) {
        Serial.println(F("SPI OLED allocation failed! Check wiring."));
        for (;;); // Freeze the board if screen is not found
    }

    // Show startup message
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(25, 25);
    display.println("SYSTEM ONLINE");
    display.display();
    delay(2000);
}

// Software debouncing function to filter out hardware noise
int readSensorStable() {
    int readings = 0;
    for (int i = 0; i < 5; i++) {
        readings += digitalRead(irSensorPin);
        delay(10);
    }
    return (readings >= 3) ? 1 : 0;
}

void loop() {
    // Read the IR sensor (0 = Closed, 1 = Open usually)
    int eyeState = readSensorStable();

    if (eyeState == 0) { 
        // Eye is CLOSED
        if (sleepTimerStart == 0) {
            sleepTimerStart = millis(); // Start timer
        } 
        else if (millis() - sleepTimerStart >= drowsyLimitMs) {
            // Trigger Alarm
            isAlarmOn = true;
            digitalWrite(buzzerPin, HIGH);
            digitalWrite(ledPin, HIGH);

            // Update display only if state changed
            if (lastDisplayState != 1) {
                display.clearDisplay();
                display.setTextSize(2); 
                display.setCursor(15, 25);
                display.println("WAKE UP!");
                display.display();
                lastDisplayState = 1; 
            }
        }
    } 
    else { 
        // Eye is OPEN - Reset to Safe State
        isAlarmOn = false;
        sleepTimerStart = 0;
        digitalWrite(buzzerPin, LOW);
        digitalWrite(ledPin, LOW);

        // Update display only if state changed
        if (lastDisplayState != 0) {
            display.clearDisplay();
            display.setTextSize(1); 
            display.setCursor(25, 20);
            display.println("Driver Awake");
            display.setCursor(25, 40);
            display.println("Monitoring...");
            display.display();
            lastDisplayState = 0; 
        }
    }

    delay(50); // Stability delay
}