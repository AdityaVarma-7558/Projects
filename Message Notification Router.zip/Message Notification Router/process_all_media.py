import os
import sys
import time
import json
import pandas as pd

code_dir = os.path.join(os.path.dirname(__file__), 'code')
if code_dir not in sys.path:
    sys.path.insert(0, code_dir)

from code.data_loader import DataLoader
from code.media_processor import MediaProcessor

def main():
    print("==========================================")
    print("Standalone 33-Media Groq Extraction Pass")
    print("==========================================")

    data_dir = "dataset"
    dl = DataLoader(data_dir)
    mp = MediaProcessor()

    # Load messages
    messages_df = pd.read_csv(os.path.join(data_dir, "messages.csv"))

    # Collect all unique media_id and media_type pairs
    media_items = []
    seen = set()
    for _, row in messages_df.iterrows():
        m_type = str(row.get("media_type", "")).strip()
        m_id = str(row.get("media_id", "")).strip()
        if m_type in ["image", "voice"] and m_id and m_id != "nan" and m_id not in seen:
            seen.add(m_id)
            media_items.append((m_type, m_id))

    print(f"Found {len(media_items)} unique media items to process.")

    # Set inter-call sleep to 1.0 seconds
    call_count = 0
    for m_type, m_id in media_items:
        call_count += 1
        path = ""
        if m_type == "image":
            path = dl.get_image_path(m_id)
        elif m_type == "voice":
            path = dl.get_voice_note_path(m_id)

        print(f"[{call_count}/{len(media_items)}] Processing {m_type} {m_id} ({path})...")
        res = mp.process_media(m_type, m_id, path)

        if mp.groq_client:
            print("  Sleeping 1s for Groq API pacing...")
            time.sleep(1.0)

    # Verify cache
    cache_file = "code/media_cache.json"
    if os.path.exists(cache_file):
        with open(cache_file, "r", encoding="utf-8") as f:
            cache_data = json.load(f)
        print("------------------------------------------")
        print(f"Extraction complete! Total entries in '{cache_file}': {len(cache_data)}")
        print("------------------------------------------")

if __name__ == "__main__":
    main()
