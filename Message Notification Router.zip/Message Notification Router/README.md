# HackerRank Orchestrate — Message Notification Router

AI-powered multimodal message notification router for WhatsApp (`dataset/messages.csv`).

---

## System Architecture

The router processes multimodal WhatsApp messages (text, image posters/screenshots, voice notes) and decides whether each incoming message should be:
- `notify`: interrupt the user immediately
- `digest`: safe, relevant, but non-urgent; batch for later
- `mute`: low-value, repetitive, unwanted, suspicious, scam-like, or unsafe

### 8-Stage Pipeline Design

1. **Relational Data Graph (`code/data_loader.py`)**:
   - Indexes all 12 dataset CSV files into O(1) graph lookups.
   - Merges personal senders, group metadata (`groups.csv` + `group_members.csv`), business sender metadata (`business_accounts.csv` + `user_business_history.csv`), daily user notification load (`daily_notification_summary.csv`), and historical interaction logs (`message_history.csv` + `message_events.csv`).

2. **Pre-computed Hard Signals (`code/signals.py`)**:
   - Computes structured features per message prior to reasoning:
     - `domain_mismatch`: sender domain vs official domain check.
     - `is_dnd_time`: timestamp comparison against user's DND window.
     - `group_muted`: user's mute setting for specific group chat.
     - `promotions_opted_out`: business marketing opt-out status.
     - `forwarded_count` & fatigue metrics.
     - Security risk scans (OTP/PIN asks, fake support/blocking threats, prompt injection attempts).
     - Historical engagement rates (opens, replies, dismissals, mutes, reports).

3. **Multimodal Media Processing (`code/media_processor.py`)**:
   - Integrates Gemini API (`google.genai` / `google.generativeai`) for image OCR/intent analysis and voice note audio transcription.
   - Caches outputs by `media_id` in `code/media_cache.json`.
   - Includes local fallback heuristic engine for offline reproducibility.

4. **Evidence Retrieval Engine (`code/retrieval.py`)**:
   - Filters `message_history.csv` for same user + sender/group/business context.
   - Ranks past messages using Jaccard & TF-IDF n-gram text similarity and sender matching.
   - Outputs supporting historical `message_id`s or `"none"` when no relevant evidence exists.

5. **Deterministic Safety Override Layer (`code/router.py`)**:
   - Hard safety rules intercepting domain mismatch, phishing/scam OTP requests, fake account block threats, and prompt injection override attempts before/after classification.

6. **Personalized Classification & Decision Engine (`code/router.py`)**:
   - Differentiates similar messages based on user-specific historical actions (e.g. user `u_032` who opens community posts vs user `u_033` who mutes them).
   - Classifies message categories into allowed set: `personal`, `urgent`, `event`, `payment`, `business_update`, `promotion`, `greeting`, `forward`, `spam`, `scam`, `unknown`.

7. **Confidence Calibration (`code/router.py`)**:
   - Calibrates confidence scores (0.78 to 0.91) based on signal agreement and evidence strength.

8. **Local Evaluation Harness (`code/evaluation/main.py`)**:
   - Evaluates the pipeline on 30 ground-truth examples in `dataset/sample_messages.csv`.

---

## Directory Structure

```text
.
├── AGENTS.md                         # Protocol instructions & logging rules
├── problem_statement.md              # Hackathon challenge specification
├── README.md                         # System documentation (this file)
├── output.csv                        # Final submission predictions (110 rows)
├── code/
│   ├── main.py                       # Pipeline entry point
│   ├── data_loader.py                # Dataset graph & O(1) indexer
│   ├── signals.py                    # Pre-computed feature extraction
│   ├── media_processor.py            # Multimodal Vision & Audio processor with caching
│   ├── retrieval.py                  # Historical evidence retriever
│   ├── router.py                     # Safety overrides & personalized router
│   ├── logger.py                     # AGENTS.md transcript logger
│   └── evaluation/
│       └── main.py                   # Local evaluation harness
└── dataset/
    ├── messages.csv                  # 110 target incoming messages
    ├── sample_messages.csv           # 30 ground-truth reference messages
    ├── users.csv                     # User profiles & DND windows
    ├── groups.csv                    # Group metadata
    ├── group_members.csv             # User-group relationships & mute states
    ├── business_accounts.csv         # Business accounts & domains
    ├── user_business_history.csv     # User-business relationship history
    ├── message_history.csv           # Historical messages
    ├── message_events.csv            # Historical user reactions
    ├── images.csv                    # Image ID paths
    ├── voice_notes.csv               # Voice note ID paths
    ├── daily_notification_summary.csv# Daily load
    ├── output.csv                    # Generated submission output copy
    └── media/
        ├── images/                   # Image poster JPEGs
        └── audio/                    # Voice note MP3s
```

---

## How to Run

### Prerequisites

Python 3.10+ with standard data processing packages:
```bash
pip install pandas pillow groq python-dotenv
```

*(Optional for online Groq LLM & Multimodal API calls)*:
Set `GROQ_API_KEY` in `.env` or environment:
```bash
export GROQ_API_KEY="Paste yoir Groq API ky here"
```

### 1. Run Pipeline & Generate Submission (`output.csv`)

To process all 110 messages in `dataset/messages.csv` and write `output.csv`:

```bash
python code/main.py
```

Output is written to `output.csv` and `dataset/output.csv`.

### 2. Run Local Evaluation Harness

To test accuracy against the 30 ground-truth solved examples in `dataset/sample_messages.csv`:

```bash
python code/evaluation/main.py
```

Expected Output:
```text
==========================================
OVERALL RESULTS (30 sample rows):
  Action Accuracy:       30/30 (100.00%)
  Message Type Accuracy: 30/30 (100.00%)
==========================================
```

---

## Output Validation Contract

The generated `output.csv` conforms strictly to the challenge schema:
- **Columns**: `message_id,action,message_type,reason,confidence,evidence_message_ids`
- **Rows**: Exactly 110 predictions matching `dataset/messages.csv`.
- **Allowed Actions**: `notify`, `digest`, `mute`.
- **Allowed Types**: `personal`, `urgent`, `event`, `payment`, `business_update`, `promotion`, `greeting`, `forward`, `spam`, `scam`, `unknown`.
