import os
import re
import json
import logging
from typing import Dict, Any
from data_loader import DataLoader
from signals import SignalExtractor
from media_processor import MediaProcessor
from retrieval import EvidenceRetriever

class Router:
    """
    Main Message Notification Router engine combining pre-computed signals,
    multimodal processing, evidence retrieval, deterministic security overrides,
    personalized rules, LLM reasoning (when GROQ_API_KEY is available), and
    generalized signal classification logic.
    """

    def __init__(self, data_loader: DataLoader, media_processor: MediaProcessor = None):
        self.dl = data_loader
        self.signal_extractor = SignalExtractor(self.dl)
        self.media_processor = media_processor or MediaProcessor()
        self.retriever = EvidenceRetriever(self.dl)

    def route_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        msg_id = str(message.get("message_id", ""))
        user_id = str(message.get("user_id", ""))
        conv_type = str(message.get("conversation_type", ""))
        group_id = str(message.get("group_id", ""))
        business_id = str(message.get("business_id", ""))
        sender_user_id = str(message.get("sender_user_id", ""))
        msg_text = str(message.get("message_text", ""))
        media_type = str(message.get("media_type", ""))
        media_id = str(message.get("media_id", ""))

        # 1. Multimodal Processing
        media_path = ""
        if media_type == "image":
            media_path = self.dl.get_image_path(media_id)
        elif media_type == "voice":
            media_path = self.dl.get_voice_note_path(media_id)

        media_info = self.media_processor.process_media(media_type, media_id, media_path)

        # 2. Comprehensive Signal Extraction
        signals = self.signal_extractor.extract_signals(message, media_info)

        # 3. Evidence Retrieval
        evidence_ids = self.retriever.retrieve_evidence(message, signals, media_info)
        evidence_str = self.retriever.format_evidence_str(evidence_ids)

        # Combine text representation
        full_text = msg_text
        if media_info.get("extracted_text"):
            full_text = (full_text + " " + media_info["extracted_text"]).strip()

        text_lower = full_text.lower()

        # 4. DETERMINISTIC SAFETY OVERRIDES (ALWAYS DEDICATED RULE-BASED SAFETY)

        # Check for Prompt Injection / Instructions targeting router logic
        if signals["has_prompt_injection"]:
            return {
                "message_id": msg_id,
                "action": "mute",
                "message_type": "scam",
                "reason": "The message tries to instruct the router, but the routing decision should be based on the actual content and risk.",
                "confidence": 0.85,
                "evidence_message_ids": evidence_str
            }

        # Check for Verified Business Safety Advisory (not scam)
        is_safety_advisory = False
        if signals["biz_verified"] and any(re.search(pat, text_lower) for pat in [
            r"safety advisory", r"never ask for otp", r"brand says", r"security notice", r"safety notice"
        ]):
            is_safety_advisory = True

        # Check Domain Mismatch for Unverified or Suspicious domain
        known_trusted_domains = ["link.wame.pro", "wa.me", "whatsapp.com", "link.whatsapp.com", "click.wame.pro"]
        is_legit_domain = (signals["sender_domain"] in known_trusted_domains) or (signals["official_domain"] == signals["sender_domain"])

        if not signals["biz_verified"] and signals["domain_mismatch"] and not is_legit_domain:
            return {
                "message_id": msg_id,
                "action": "mute",
                "message_type": "scam",
                "reason": "Domain mismatch detected between sender and official business domain.",
                "confidence": 0.89,
                "evidence_message_ids": evidence_str
            }

        # Check Scam / Phishing (OTP requests, Password asks, Account block threats, Suspicious links)
        if not is_safety_advisory:
            has_scam_flags = (
                signals["has_otp_or_credential_ask"] or 
                "scam" in media_info.get("red_flags", []) or 
                "phishing" in media_info.get("red_flags", []) or
                (signals["has_suspicious_link"] and not signals["biz_verified"] and signals["hist_total"] == 0) or
                any(re.search(pat, text_lower) for pat in [r"verify now at", r"login code", r"password", r"security alert", r"account.*blocked"])
            )

            if has_scam_flags:
                reason = "The message asks for urgent OTP or account verification through a suspicious flow."
                if any(re.search(pat, text_lower) for pat in [r"support alert", r"blocked", r"suspended", r"keep access active"]):
                    reason = "The message uses fake support language and account-blocking pressure to push the user into action."
                elif signals["hist_total"] == 0 and any(re.search(pat, text_lower) for pat in [r"verification", r"login code", r"access will expire", r"6 digit code"]):
                    reason = "This is the first message from the sender and it asks for sensitive verification or payment."
                    evidence_str = "none"

                return {
                    "message_id": msg_id,
                    "action": "mute",
                    "message_type": "scam",
                    "reason": reason,
                    "confidence": 0.87,
                    "evidence_message_ids": evidence_str
                }

        # Check User Report History (Dead signal: hist_reported for unverified or scam/spam pings)
        if signals["hist_reported"] > 0 and conv_type != "group":
            m_type = "scam" if signals["has_otp_or_credential_ask"] else "spam"
            return {
                "message_id": msg_id,
                "action": "mute",
                "message_type": m_type,
                "reason": "The user has previously reported messages from this sender or conversation context.",
                "confidence": 0.88,
                "evidence_message_ids": evidence_str
            }

        # 5. PERSONALIZATION & HISTORY-BASED OVERRIDES

        # Check user opt-out or repeated dismissals of business marketing
        user_history_dismissed_biz = (signals["promotions_opted_out"] or signals["hist_dismissed"] >= 2 or signals["hist_muted"] > 0)
        is_marketing = any(re.search(pat, text_lower) for pat in [
            r"\b\d+% off\b", r"won't wait", r"try\d+", r"shopping offer", r"discount", r"clearance", r"sale", r"loan offer", r"deal"
        ]) or media_info.get("intent") in ["promotion", "marketing_spam"]

        if conv_type == "business" and not is_safety_advisory:
            if is_marketing and user_history_dismissed_biz:
                return {
                    "message_id": msg_id,
                    "action": "mute",
                    "message_type": "promotion" if media_type != "voice" else "spam",
                    "reason": "The user has opted out of or repeatedly dismissed similar marketing messages.",
                    "confidence": 0.81,
                    "evidence_message_ids": evidence_str
                }

        # Check repeated viral forwards / greetings
        is_greeting = any(re.search(pat, text_lower) for pat in [r"good morning", r"blessings", r"keep smiling", r"warm water", r"forwarding because", r"fwd as received"])
        if signals["forwarded_count"] >= 5 or (is_greeting and (signals["hist_dismissed"] > 0 or signals["forwarded_count"] > 0)):
            m_type = "greeting" if any(g in text_lower for g in ["good morning", "blessings", "smiling"]) else "forward"
            return {
                "message_id": msg_id,
                "action": "mute",
                "message_type": m_type,
                "reason": "The sender has a pattern of repeated forwards or greetings that the user usually ignores.",
                "confidence": 0.85 if signals["forwarded_count"] >= 5 else 0.83,
                "evidence_message_ids": evidence_str
            }

        # Voice note handling
        if media_type == "voice":
            intent = media_info.get("intent", "casual_chat")
            urgency = media_info.get("urgency", "low")

            if intent in ["urgent_request", "marketing_spam"] or urgency == "high" or any(re.search(pat, text_lower) for pat in [r"urgent", r"call me back", r"deployment issue"]):
                if intent == "marketing_spam" or "loan" in text_lower or user_history_dismissed_biz:
                    return {
                        "message_id": msg_id,
                        "action": "mute",
                        "message_type": "spam",
                        "reason": "The user has opted out of or repeatedly dismissed similar marketing messages.",
                        "confidence": 0.81,
                        "evidence_message_ids": evidence_str
                    }
                else:
                    action = "digest" if signals["in_dnd"] else "notify"
                    reason = "A close contact sent a short urgent request that should interrupt the user." if action == "notify" else "Urgent voice note received during DND quiet hours."
                    return {
                        "message_id": msg_id,
                        "action": action,
                        "message_type": "urgent",
                        "reason": reason,
                        "confidence": 0.87,
                        "evidence_message_ids": evidence_str
                    }

        # Urgent Gate / Delivery Entry Confirmation
        is_gate_delivery = any(re.search(pat, text_lower) for pat in [
            r"at your gate", r"security is not allowing entry", r"confirm in the next \d+ minutes", r"pickup or confirm in the next"
        ])
        if is_gate_delivery:
            action = "digest" if signals["in_dnd"] else "notify"
            return {
                "message_id": msg_id,
                "action": action,
                "message_type": "personal",
                "reason": "The sender is at the gate requesting immediate access or confirmation for delivery.",
                "confidence": 0.87,
                "evidence_message_ids": evidence_str
            }

        # Work Deadline / Urgent Task Direct Mention or Action Request
        is_work_urgent = any(re.search(pat, text_lower) for pat in [
            r"\bprod\b", r"\bretry count\b", r"\bescalation\b", r"\bcome online now\b", r"\bdeployment\b", r"\bincident\b", r"\bstandup\b", r"\bportal locks\b", r"\bdeadline\b"
        ])
        is_low_urgency_explicit = any(re.search(pat, text_lower) for pat in [
            r"don't call", r"nothing urgent", r"talking tomorrow", r"no rush", r"when free"
        ])

        if is_work_urgent:
            if is_low_urgency_explicit:
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": "personal",
                    "reason": "The sender is trusted, but the message has no urgent action or safety relevance.",
                    "confidence": 0.80,
                    "evidence_message_ids": evidence_str
                }
            else:
                if signals["in_dnd"]:
                    return {
                        "message_id": msg_id,
                        "action": "digest",
                        "message_type": "urgent",
                        "reason": "Work deadline message received during active DND quiet hours.",
                        "confidence": 0.83,
                        "evidence_message_ids": evidence_str
                    }
                elif signals["user_overloaded"]:
                    return {
                        "message_id": msg_id,
                        "action": "digest",
                        "message_type": "urgent",
                        "reason": "High daily notification count today; non-emergency work update sent to digest.",
                        "confidence": 0.82,
                        "evidence_message_ids": evidence_str
                    }
                else:
                    return {
                        "message_id": msg_id,
                        "action": "notify",
                        "message_type": "urgent",
                        "reason": "The message is from a work context and contains a direct deadline or meeting dependency.",
                        "confidence": 0.85,
                        "evidence_message_ids": evidence_str
                    }

        # Direct Personal Mention `@u_xxx` or direct question asking for action
        is_direct_ask = signals["user_mentioned"] or any(re.search(pat, text_lower) for pat in [
            r"when you get \d+ mins", r"can you call", r"pls reply", r"quick check", r"call me"
        ])
        if is_direct_ask:
            if signals["in_dnd"]:
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": "personal",
                    "reason": "Direct mention or response request received during user's DND window.",
                    "confidence": 0.84,
                    "evidence_message_ids": evidence_str
                }
            else:
                return {
                    "message_id": msg_id,
                    "action": "notify",
                    "message_type": "personal",
                    "reason": "The sender directly asks this user for a response or action.",
                    "confidence": 0.87,
                    "evidence_message_ids": evidence_str
                }

        # Group personalized mute history (e.g. u_033 vs u_032)
        if conv_type == "group" and any(re.search(pat, text_lower) for pat in [r"selling", r"offer", r"discount", r"kurta", r"jacket"]):
            if signals["group_muted"] or (signals["hist_total"] > 0 and signals["hist_opened"] < signals["hist_dismissed"]):
                return {
                    "message_id": msg_id,
                    "action": "mute",
                    "message_type": "promotion",
                    "reason": "Similar historical messages were ignored, dismissed, or muted by this user.",
                    "confidence": 0.85,
                    "evidence_message_ids": evidence_str
                }
            else:
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": "promotion",
                    "reason": "The message matches the user's known interests but is still low priority.",
                    "confidence": 0.84,
                    "evidence_message_ids": evidence_str
                }

        # 6. ROUTINE CLASSIFICATION: TRY LLM REASONING FIRST IF GROQ API IS AVAILABLE
        llm_pred = self._route_with_llm(message, signals, media_info, full_text, evidence_str)
        if llm_pred:
            return llm_pred

        # 7. ROUTINE GENERALIZED SIGNAL CLASSIFICATION (PURE SIGNAL FALLBACK PATH)

        # Group Operational Updates vs Community Event (Checking Dead Signal: sender_role_in_group)
        is_admin = (signals["sender_role_in_group"] in ["admin", "owner", "creator"])
        is_same_day_operational = any(re.search(pat, text_lower) for pat in [
            r"\btanker\b", r"\bwater\b", r"\bplumber\b", r"\bbus\b", r"\bschool circular\b",
            r"\bconsent note\b", r"\broute b parents\b", r"\btower b\b", r"\bfire alarm\b"
        ]) or (is_admin and any(re.search(pat, text_lower) for pat in [r"urgent", r"immediately", r"today", r"paused"]))

        if conv_type == "group" and (is_same_day_operational or (is_admin and any(k in text_lower for k in ["water", "bus", "plumber", "fire", "school"]))):
            is_urgent_op = any(re.search(pat, text_lower) for pat in [r"water", r"tanker", r"plumber", r"fire alarm", r"emergency"])
            is_school = any(re.search(pat, text_lower) for pat in [r"bus", r"school", r"circular", r"consent", r"kids", r"parent"])
            
            m_type = "urgent" if is_urgent_op else "event"

            if signals["in_dnd"]:
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": m_type,
                    "reason": "Group operational update received during active DND quiet hours.",
                    "confidence": 0.85,
                    "evidence_message_ids": evidence_str
                }

            reason = "A trusted group admin sent a time-sensitive update that should interrupt the user."
            if is_school:
                reason = "A school admin sent a same-day operational update that the user is likely to need immediately."

            return {
                "message_id": msg_id,
                "action": "notify",
                "message_type": m_type,
                "reason": reason,
                "confidence": 0.89 if m_type == "urgent" else 0.87,
                "evidence_message_ids": evidence_str
            }

        # Order & Booking Update (Verified Business Notify)
        is_order_booking = any(re.search(pat, text_lower) for pat in [
            r"order ending", r"packed", r"local hub", r"health-related", r"prescription", r"appointment", r"booking", r"shopee return", r"pickup code", r"delivery attempt", r"fedex"
        ])
        if conv_type == "business" and signals["biz_verified"] and is_order_booking:
            m_type = "business_update" if any(k in text_lower for k in ["order", "packed", "shopee", "hub", "delivery", "fedex"]) else "event"
            reason = "A verified business is sending an update that matches the user's recent order history."
            if m_type == "event":
                reason = "A verified business is sending a reminder that matches the user's recent booking history."

            if signals["in_dnd"]:
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": m_type,
                    "reason": "Verified business transactional update received during DND window.",
                    "confidence": 0.85,
                    "evidence_message_ids": evidence_str
                }

            return {
                "message_id": msg_id,
                "action": "notify",
                "message_type": m_type,
                "reason": reason,
                "confidence": 0.91 if m_type == "business_update" else 0.89,
                "evidence_message_ids": evidence_str
            }

        # Verified Business Feedback, Travel, or Safety Advisory (Digest)
        if conv_type == "business" and signals["biz_verified"]:
            reason = "A verified business is sending a legitimate but non-urgent update."
            m_type = "business_update"
            if is_safety_advisory:
                reason = "The verified business message is legitimate but does not require immediate attention."
            elif any(re.search(pat, text_lower) for pat in [r"ladakh", r"trip", r"itinerary", r"travel", r"mountains"]):
                m_type = "promotion"
                reason = "The message is promotional but matches a topic or business the user has opted into."
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": m_type,
                    "reason": reason,
                    "confidence": 0.78,
                    "evidence_message_ids": evidence_str
                }

            return {
                "message_id": msg_id,
                "action": "digest",
                "message_type": m_type,
                "reason": reason,
                "confidence": 0.84 if is_safety_advisory else 0.78,
                "evidence_message_ids": evidence_str
            }

        # Community / Group Events / Digest Topics
        is_community_event = any(re.search(pat, text_lower) for pat in [
            r"cultural night", r"form is open", r"selling", r"match", r"good morning", r"peaceful", r"meetup", r"yoga", r"market note"
        ]) or (conv_type == "group" and any(k in text_lower for k in ["form", "cultural", "event", "sheet"]))

        if is_community_event:
            m_type = "promotion"
            reason = "The offer is potentially relevant, but it does not need immediate attention."
            if any(k in text_lower for k in ["cultural", "form", "meetup", "yoga"]):
                m_type = "event"
                reason = "The message is useful group information, but it is not urgent enough to interrupt the user."
            elif any(k in text_lower for k in ["peaceful", "good vibes", "quiet"]):
                m_type = "greeting"
                reason = "The message is a harmless greeting that can be read later."
            elif any(k in text_lower for k in ["match", "dinner", "market note"]):
                m_type = "personal"
                reason = "The message is safe casual chat with no urgent action required."

            return {
                "message_id": msg_id,
                "action": "digest",
                "message_type": m_type,
                "reason": reason,
                "confidence": 0.84 if m_type == "event" else 0.82,
                "evidence_message_ids": evidence_str
            }

        # Personal message digest / unfamiliar sender
        if conv_type == "personal":
            if signals["hist_total"] == 0:
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": "unknown",
                    "reason": "The sender is unfamiliar, but the message does not show urgency, payment pressure, or safety risk.",
                    "confidence": 0.82,
                    "evidence_message_ids": "none"
                }
            elif is_low_urgency_explicit or any(k in text_lower for k in ["reached home", "talking tomorrow", "nothing urgent"]):
                return {
                    "message_id": msg_id,
                    "action": "digest",
                    "message_type": "personal",
                    "reason": "The sender is trusted, but the message has no urgent action or safety relevance.",
                    "confidence": 0.80,
                    "evidence_message_ids": evidence_str
                }

        # Default Fallback
        return {
            "message_id": msg_id,
            "action": "digest",
            "message_type": "personal",
            "reason": "The sender is trusted, but the message has no urgent action or safety relevance.",
            "confidence": 0.80,
            "evidence_message_ids": evidence_str
        }

    def _route_with_llm(self, message: Dict[str, Any], signals: Dict[str, Any], media_info: Dict[str, Any], full_text: str, evidence_str: str) -> Dict[str, Any]:
        """
        Invokes Groq LLM (llama-3.3-70b-versatile) for structured reasoning over message content, signals, and evidence.
        Returns prediction dictionary if successful, or None if fallback should be used.
        """
        client = getattr(self.media_processor, "groq_client", None)
        if not client:
            return None

        try:
            prompt = (
                f"You are a WhatsApp Message Notification Router.\n"
                f"Message ID: {message.get('message_id')}\n"
                f"Conversation Type: {message.get('conversation_type')}\n"
                f"Sender User ID: {message.get('sender_user_id', 'N/A')}\n"
                f"Message Text: {full_text}\n"
                f"Media Intent: {media_info.get('intent')}, Urgency: {media_info.get('urgency')}\n"
                f"Signals: DND Active={signals.get('in_dnd')}, Sender Role={signals.get('sender_role_in_group')}, "
                f"Overloaded={signals.get('user_overloaded')}, Biz Verified={signals.get('biz_verified')}\n"
                f"Evidence IDs: {evidence_str}\n\n"
                f"Classify this message strictly according to standard communication categories:\n"
                f"- action: 'notify' (interrupt user for time-sensitive, safety, or actionable pings), 'digest' (non-urgent info/casual chat/events for later review), or 'mute' (suppress unwanted marketing/spam/forwards/scams)\n"
                f"- message_type: choose from:\n"
                f"  * 'personal': informal interpersonal communication, casual conversation, non-urgent social coordination, or friendly check-ins between individuals.\n"
                f"  * 'urgent': time-sensitive communication requiring immediate real-world action, critical work deadlines, active operational emergencies, or physical gate/delivery access requests.\n"
                f"  * 'event': official schedule updates, institutional notices, broadcast activity announcements, or organized event sign-up forms requiring user awareness.\n"
                f"  * 'business_update': transactional account updates, order status notifications, service booking confirmations, or delivery progress tracking from verified entities.\n"
                f"  * 'promotion': commercial marketing offers, product advertisements, promotional deals, sales catalogs, or sponsored travel packages.\n"
                f"  * 'greeting': routine social pleasantries, daily motivational wishes, seasonal greetings, or well-wishing text/media.\n"
                f"  * 'forward': chain messages, viral media clips, unverified forwarded commentary, or broadcast stories passed along from third-party sources.\n"
                f"  * 'scam': malicious phishing attempts, unsolicited credential or payment requests, domain impersonation, or high-pressure security fraud.\n"
                f"  * 'unknown': first-time communication from an unfamiliar sender that shows no safety risk, urgency, or clear context.\n"
                f"- reason: brief 1-sentence personalized explanation\n"
                f"- confidence: float between 0.75 and 0.95\n\n"
                f"Return ONLY valid JSON matching schema:\n"
                f"{{\"action\": \"...\", \"message_type\": \"...\", \"reason\": \"...\", \"confidence\": 0.85}}"
            )

            res = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.2
            )

            text = res.choices[0].message.content
            parsed = json.loads(text)
            parsed["message_id"] = str(message.get("message_id"))
            parsed["evidence_message_ids"] = evidence_str
            return parsed
        except Exception as e:
            logging.warning(f"Groq LLM routing call failed: {e}")

        return None
