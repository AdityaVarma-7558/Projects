import os
import sys
import pandas as pd

# Add code directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from data_loader import DataLoader
from media_processor import MediaProcessor
from router import Router
from logger import log_action

def evaluate_sample_messages():
    sample_path = "dataset/sample_messages.csv"
    if not os.path.exists(sample_path):
        print(f"Sample messages file not found at {sample_path}")
        return

    sample_df = pd.read_csv(sample_path).fillna("")
    print(f"Loaded {len(sample_df)} sample messages for evaluation.")

    dl = DataLoader(dataset_dir="dataset")
    media_proc = MediaProcessor()
    router = Router(data_loader=dl, media_processor=media_proc)

    correct_actions = 0
    correct_types = 0
    total = len(sample_df)

    results = []

    print("\n--- Evaluation Results per Sample Message ---")
    for idx, row in sample_df.iterrows():
        msg_id = row["message_id"]
        true_action = row["action"]
        true_type = row["message_type"]
        true_confidence = float(row["confidence"]) if row["confidence"] != "" else 0.8
        true_evidence = str(row["evidence_message_ids"])

        msg_dict = row.to_dict()
        pred = router.route_message(msg_dict)

        pred_action = pred["action"]
        pred_type = pred["message_type"]
        pred_reason = pred["reason"]
        pred_confidence = float(pred["confidence"])
        pred_evidence = pred["evidence_message_ids"]

        action_match = (pred_action == true_action)
        type_match = (pred_type == true_type)

        if action_match:
            correct_actions += 1
        if type_match:
            correct_types += 1

        print(f"[{msg_id}]")
        print(f"  True Action: {true_action:<7} | Pred Action: {pred_action:<7} | Match: {action_match}")
        print(f"  True Type:   {true_type:<14} | Pred Type:   {pred_type:<14} | Match: {type_match}")
        print(f"  Pred Reason: {pred_reason}")
        print(f"  Evidence (True/Pred): {true_evidence} / {pred_evidence}\n")

        results.append({
            "msg_id": msg_id,
            "action_match": action_match,
            "type_match": type_match,
            "pred_action": pred_action,
            "true_action": true_action,
            "pred_type": pred_type,
            "true_type": true_type
        })

    action_acc = (correct_actions / total) * 100.0
    type_acc = (correct_types / total) * 100.0

    print("==========================================")
    print(f"OVERALL RESULTS ({total} sample rows):")
    print(f"  Action Accuracy:       {correct_actions}/{total} ({action_acc:.2f}%)")
    print(f"  Message Type Accuracy: {correct_types}/{total} ({type_acc:.2f}%)")
    print("==========================================")

    log_action(
        title="Evaluated Router on Sample Messages",
        user_prompt="Run local evaluation harness on sample_messages.csv",
        summary=f"Evaluated routing pipeline on {total} sample messages. Action Accuracy: {action_acc:.2f}%, Message Type Accuracy: {type_acc:.2f}%.",
        actions=[f"Executed evaluation on sample_messages.csv", f"Achieved {action_acc:.1f}% action accuracy"]
    )

if __name__ == "__main__":
    evaluate_sample_messages()
