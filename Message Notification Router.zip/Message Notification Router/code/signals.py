import re
from datetime import datetime
from typing import Dict, Any, List
from data_loader import DataLoader

def parse_time_window(dnd_str: str):
    """
    Parses a window like '22:00-07:00' or '23:00-06:00'.
    Returns (start_hour, start_min, end_hour, end_min).
    """
    if not dnd_str or '-' not in dnd_str:
        return None
    try:
        start_part, end_part = dnd_str.split('-')
        sh, sm = map(int, start_part.split(':'))
        eh, em = map(int, end_part.split(':'))
        return (sh, sm, eh, em)
    except Exception:
        return None

def is_in_dnd_window(created_at_str: str, dnd_str: str) -> bool:
    """
    Checks if created_at timestamp falls into DND window.
    """
    parsed = parse_time_window(dnd_str)
    if not parsed:
        return False
    sh, sm, eh, em = parsed
    try:
        # created_at format e.g. "2026-07-31 11:09" or ISO format
        dt = datetime.strptime(str(created_at_str).strip(), "%Y-%m-%d %H:%M")
    except Exception:
        try:
            dt = datetime.fromisoformat(str(created_at_str).strip())
        except Exception:
            return False

    msg_time = dt.hour * 60 + dt.minute
    dnd_start = sh * 60 + sm
    dnd_end = eh * 60 + em

    if dnd_start > dnd_end:
        # Overnight DND e.g. 22:00 to 07:00
        return msg_time >= dnd_start or msg_time < dnd_end
    else:
        # Same day DND e.g. 01:00 to 06:00
        return dnd_start <= msg_time < dnd_end

class SignalExtractor:
    def __init__(self, data_loader: DataLoader):
        self.dl = data_loader

    def extract_signals(self, message: Dict[str, Any], media_info: Dict[str, Any] = None) -> Dict[str, Any]:
        msg_id = str(message.get("message_id", ""))
        user_id = str(message.get("user_id", ""))
        conv_type = str(message.get("conversation_type", ""))
        group_id = str(message.get("group_id", ""))
        business_id = str(message.get("business_id", ""))
        sender_user_id = str(message.get("sender_user_id", ""))
        created_at = str(message.get("created_at", ""))
        msg_text = str(message.get("message_text", ""))
        forwarded_count = int(message.get("forwarded_count", 0) or 0)

        # Include media text/intent if available
        full_text_for_scan = msg_text
        if media_info:
            extracted_text = media_info.get("extracted_text", "")
            if extracted_text:
                full_text_for_scan += "\n" + extracted_text

        text_lower = full_text_for_scan.lower()

        # 1. User signals
        user_data = self.dl.get_user(user_id)
        dnd_window = user_data.get("do_not_disturb_window", "")
        in_dnd = is_in_dnd_window(created_at, dnd_window)

        # 2. Group signals
        group_data = self.dl.get_group(group_id) if group_id else {}
        group_member_data = self.dl.get_group_member(group_id, user_id) if group_id else {}
        
        group_muted = False
        raw_muted = group_member_data.get("group_muted_by_user", False)
        if str(raw_muted).lower() in ["1", "true", "yes"]:
            group_muted = True

        sender_role_in_group = "member"
        if group_id and sender_user_id:
            sender_member_data = self.dl.get_group_member(group_id, sender_user_id)
            sender_role_in_group = sender_member_data.get("role", "member")

        user_mentioned = f"@{user_id}".lower() in text_lower or f"@{user_id.replace('u_', '')}".lower() in text_lower

        # 3. Business signals
        biz_data = self.dl.get_business(business_id) if business_id else {}
        ubh_data = self.dl.get_user_business_history(user_id, business_id) if business_id else {}

        official_domain = str(biz_data.get("official_domain", "")).strip().lower()
        sender_domain = str(biz_data.get("domain_used_by_sender", "")).strip().lower()
        biz_verified = str(biz_data.get("verified", "")).lower() in ["1", "true", "yes"]

        domain_mismatch = False
        if official_domain and sender_domain and official_domain != sender_domain:
            domain_mismatch = True

        promotions_opted_out = False
        allows_promos = ubh_data.get("allows_promotions", "")
        if str(allows_promos).lower() in ["0", "false", "no"]:
            promotions_opted_out = True
        if ubh_data.get("promotions_opted_out_at", ""):
            promotions_opted_out = True

        # 4. Security & Phishing Risk Scans
        otp_patterns = [
            r"\botp\b", r"one[- ]time password", r"verification code", r"login code",
            r"confirm password", r"verify now at", r"account[- ]login", r"security alert",
            r"wallet verification", r"account will be blocked", r"profile will be blocked",
            r"6 digit code", r"pin code", r"account number", r"bank details", r"share.*account", r"share.*bank"
        ]
        negative_disclaimer_patterns = [
            r"no payment or otp", r"no otp", r"never ask for otp", r"no payment.*required", r"don't share otp with anyone"
        ]
        is_negative_disclaimer = any(re.search(pat, text_lower) for pat in negative_disclaimer_patterns)
        has_otp_or_credential_ask = any(re.search(pat, text_lower) for pat in otp_patterns) and not is_negative_disclaimer

        suspicious_link_patterns = [
            r"http[s]?://", r"\.in\b", r"\.xyz\b", r"\.top\b", r"account-login", r"verify-access"
        ]
        has_suspicious_link = any(re.search(pat, text_lower) for pat in suspicious_link_patterns)

        prompt_injection_patterns = [
            r"ignore (all )?previous", r"routing rules", r"mark this message as",
            r"override rule", r"system instruction"
        ]
        has_prompt_injection = any(re.search(pat, text_lower) for pat in prompt_injection_patterns)

        # 5. Fatigue signal
        date_part = created_at.split()[0] if created_at else ""
        daily_sum = self.dl.get_daily_summary(user_id, date_part)
        notifications_sent_today = int(daily_sum.get("notifications_sent", 0) or 0)
        user_overloaded = notifications_sent_today >= 15

        # 6. Historical engagement statistics
        hist_total = 0
        hist_opened = 0
        hist_replied = 0
        hist_dismissed = 0
        hist_muted = 0
        hist_reported = 0

        for h in self.dl.message_history:
            if h.get("user_id") != user_id:
                continue
            
            # Match conversation context
            match = False
            if conv_type == "group" and h.get("group_id") == group_id:
                match = True
            elif conv_type == "business" and h.get("business_id") == business_id:
                match = True
            elif conv_type == "personal" and h.get("sender_user_id") == sender_user_id:
                match = True

            if match:
                hist_total += 1
                evt = h.get("event", {})
                if str(evt.get("message_opened", "")).lower() in ["1", "true"]:
                    hist_opened += 1
                if str(evt.get("message_replied", "")).lower() in ["1", "true"]:
                    hist_replied += 1
                if str(evt.get("notification_dismissed", "")).lower() in ["1", "true"]:
                    hist_dismissed += 1
                if str(evt.get("muted_after_message", "")).lower() in ["1", "true"]:
                    hist_muted += 1
                if str(evt.get("message_reported", "")).lower() in ["1", "true"]:
                    hist_reported += 1

        signals = {
            "in_dnd": in_dnd,
            "group_muted": group_muted,
            "sender_role_in_group": sender_role_in_group,
            "user_mentioned": user_mentioned,
            "biz_verified": biz_verified,
            "official_domain": official_domain,
            "sender_domain": sender_domain,
            "domain_mismatch": domain_mismatch,
            "promotions_opted_out": promotions_opted_out,
            "forwarded_count": forwarded_count,
            "has_otp_or_credential_ask": has_otp_or_credential_ask,
            "has_suspicious_link": has_suspicious_link,
            "has_prompt_injection": has_prompt_injection,
            "user_overloaded": user_overloaded,
            "notifications_sent_today": notifications_sent_today,
            "hist_total": hist_total,
            "hist_opened": hist_opened,
            "hist_replied": hist_replied,
            "hist_dismissed": hist_dismissed,
            "hist_muted": hist_muted,
            "hist_reported": hist_reported,
        }
        return signals
