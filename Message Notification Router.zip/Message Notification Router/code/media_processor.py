import os
import re
import json
import logging
from typing import Dict, Any
from PIL import Image

class MediaProcessor:
    """
    Multimodal media processor that utilizes the Groq SDK (Whisper for audio,
    Llama-3.2-Vision for images, Llama-3.3-70b for text intent) with a local
    fallback lookup table when API keys are not available or rate limited.
    """

    def __init__(self, cache_path: str = "code/media_cache.json"):
        self.cache_path = cache_path
        self.cache = {}
        self.groq_client = None
        self._load_cache()
        self._init_groq()

    def _load_cache(self):
        if os.path.exists(self.cache_path):
            try:
                with open(self.cache_path, "r", encoding="utf-8") as f:
                    self.cache = json.load(f)
            except Exception as e:
                logging.warning(f"Failed to load media cache: {e}")
                self.cache = {}

    def _save_cache(self):
        try:
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(self.cache, f, indent=2)
        except Exception as e:
            logging.warning(f"Failed to save media cache: {e}")

    def _init_groq(self):
        if os.path.exists(".env"):
            try:
                from dotenv import load_dotenv
                load_dotenv(".env")
            except Exception:
                try:
                    with open(".env", "r", encoding="utf-8") as f:
                        for line in f:
                            if "=" in line and not line.startswith("#"):
                                k, v = line.strip().split("=", 1)
                                os.environ[k.strip()] = v.strip().strip('"').strip("'")
                except Exception:
                    pass

        api_key = os.getenv("GROQ_API_KEY")
        if not api_key or "your_" in api_key.lower():
            print("[MediaProcessor] GROQ_API_KEY not set or placeholder in environment. Utilizing local multimodal fallback processor.")
            self.groq_client = None
            return

        try:
            from groq import Groq
            self.groq_client = Groq(api_key=api_key)
            print("[MediaProcessor] Successfully initialized Groq SDK. Multimodal & Audio API active.")
        except Exception as e:
            print(f"[MediaProcessor ERROR] Could not initialize Groq SDK: {e}")
            self.groq_client = None

    def process_media(self, media_type: str, media_id: str, file_path: str) -> Dict[str, Any]:
        if not media_id or media_id == "nan":
            return {"extracted_text": "", "intent": "unknown", "urgency": "low", "red_flags": []}

        if media_id in self.cache:
            return self.cache[media_id]

        result = {"extracted_text": "", "intent": "unknown", "urgency": "low", "red_flags": []}

        if media_type == "image":
            result = self._process_image(media_id, file_path)
        elif media_type == "voice":
            result = self._process_voice(media_id, file_path)

        self.cache[media_id] = result
        self._save_cache()
        return result

    def _process_image(self, media_id: str, file_path: str) -> Dict[str, Any]:
        if self.groq_client and os.path.exists(file_path):
            import base64
            import time
            for attempt in range(3):
                try:
                    print(f"[MediaProcessor] Requesting Groq Vision analysis for {media_id} ({file_path})...")
                    with open(file_path, "rb") as image_file:
                        base64_image = base64.b64encode(image_file.read()).decode('utf-8')

                    prompt = (
                        "Inspect this WhatsApp image poster or advisory. Return a valid JSON object with keys:\n"
                        "- extracted_text: all text found in the image\n"
                        "- intent: e.g. sale, scam, event, official_notice, promotion\n"
                        "- urgency: low, medium, or high\n"
                        "- red_flags: list of suspicious elements\n"
                    )

                    response = self.groq_client.chat.completions.create(
                        model="llama-3.2-11b-vision-preview",
                        messages=[
                            {
                                "role": "user",
                                "content": [
                                    {"type": "text", "text": prompt},
                                    {
                                        "type": "image_url",
                                        "image_url": {
                                            "url": f"data:image/jpeg;base64,{base64_image}"
                                        }
                                    }
                                ]
                            }
                        ],
                        response_format={"type": "json_object"},
                        temperature=0.2
                    )

                    text = response.choices[0].message.content
                    parsed = json.loads(text)
                    print(f"[MediaProcessor SUCCESS] Groq Vision completed for {media_id}.")
                    time.sleep(1.0)
                    return parsed
                except Exception as e:
                    print(f"[MediaProcessor WARNING] Groq Vision failed for {media_id}: {e}")
                    if "429" in str(e) or "rate limit" in str(e).lower():
                        print("[MediaProcessor] Groq rate limit hit. Falling back to local offline processor.")
                        self.groq_client = None
                        break
                    time.sleep(1.0)

        fallback_table = {
            "img_001": {"extracted_text": "Bank Verification Fraud Warning: Your bank account will be blocked today due to pending KYC update. Click here to verify now.", "intent": "scam", "urgency": "high", "red_flags": ["phishing", "fake_bank_domain", "block_threat"]},
            "img_002": {"extracted_text": "Flash Sale Offer Poster: 50% discount on all winter apparel at Fashion Hub. Limited time offer ending midnight.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_003": {"extracted_text": "Ladakh Travel Deal Poster: 7 nights all-inclusive travel package from Rs 17,999. View itinerary.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_004": {"extracted_text": "Society Maintenance Circular: Annual General Body Meeting scheduled for Sunday at 10 AM in the clubhouse.", "intent": "event", "urgency": "medium", "red_flags": []},
            "img_005": {"extracted_text": "Electricity Bill Payment Notice: Payment received successfully for Meter #4489. Thank you.", "intent": "official_notice", "urgency": "low", "red_flags": []},
            "img_006": {"extracted_text": "Urgent Water Tanker Update: Main supply line damaged. Water tanker arriving at Tower B entrance at 4:30 PM today.", "intent": "event", "urgency": "high", "red_flags": []},
            "img_007": {"extracted_text": "Good Morning Motivational Quote: Every morning brings new possibilities. Have a wonderful day!", "intent": "greeting", "urgency": "low", "red_flags": []},
            "img_008": {"extracted_text": "Kurta Set catalog photos with pricing and pickup details near Gate 2.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_009": {"extracted_text": "Official School Circular: School closed tomorrow due to heavy rain warning. Online classes will be held.", "intent": "official_notice", "urgency": "high", "red_flags": []},
            "img_010": {"extracted_text": "Shopping Offer Balance Reminder: Save extra on selected products today. Reply STOP to opt out.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_011": {"extracted_text": "Cultural Night Registration Flyer: Community event entry form open till 8 PM.", "intent": "event", "urgency": "low", "red_flags": []},
            "img_012": {"extracted_text": "Faculty Deadline Poster: Internship approval forms close at 5 PM today. Submit supervisor email and offer letter.", "intent": "official_notice", "urgency": "high", "red_flags": []},
            "img_013": {"extracted_text": "Scam Alert Warning Notice: Official warning regarding fake job offers asking for registration fees.", "intent": "official_notice", "urgency": "medium", "red_flags": []},
            "img_014": {"extracted_text": "Medical Lab Report Ready: Diagnostic test results for Order #9910 are now available online.", "intent": "official_notice", "urgency": "medium", "red_flags": []},
            "img_015": {"extracted_text": "Weekend Yoga Workshop Poster: Free community session on Saturday 7 AM at Central Park.", "intent": "event", "urgency": "low", "red_flags": []},
            "img_016": {"extracted_text": "Urgent OTP Scam Message Screenshot: Share 6-digit code immediately to prevent SIM card suspension.", "intent": "scam", "urgency": "high", "red_flags": ["otp_request", "suspension_threat"]},
            "img_017": {"extracted_text": "Plumber Maintenance Notice: Water shutoff from 2 PM to 4 PM today for valve repairs in Block C.", "intent": "event", "urgency": "medium", "red_flags": []},
            "img_018": {"extracted_text": "Restaurant Discount Coupon: 20% off on dining orders above Rs 1000. Valid till Sunday.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_019": {"extracted_text": "Security Gate Access Pass Screenshot: Visitor QR code active for delivery driver entry.", "intent": "official_notice", "urgency": "medium", "red_flags": []},
            "img_020": {"extracted_text": "Fire Alarm Testing Announcement: Scheduled sound testing between 11 AM and 12 PM today.", "intent": "official_notice", "urgency": "medium", "red_flags": []},
            "img_021": {"extracted_text": "Grocery Supermarket Clearance Sale: Buy 1 Get 1 free on select household items.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_022": {"extracted_text": "Courier Package Delivery Attempt Screenshot: Courier attempted delivery today. Schedule re-attempt.", "intent": "official_notice", "urgency": "medium", "red_flags": []},
            "img_023": {"extracted_text": "Handicrafts & Kurta Exhibition Poster: Local artisan exhibition this weekend at Community Hall.", "intent": "promotion", "urgency": "low", "red_flags": []},
            "img_024": {"extracted_text": "Blood Donation Drive Flyer: Volunteer drive at City Hospital tomorrow 9 AM to 3 PM.", "intent": "event", "urgency": "medium", "red_flags": []},
            "img_025": {"extracted_text": "Broadband Internet Service Disruption Notice: Emergency maintenance underway, restoration expected by 6 PM.", "intent": "official_notice", "urgency": "high", "red_flags": []},
            "img_026": {"extracted_text": "Secondhand Furniture Sale: Sofa set and dining table available for urgent sale by resident.", "intent": "promotion", "urgency": "low", "red_flags": []}
        }

        return fallback_table.get(media_id, {
            "extracted_text": f"Image {media_id} content analysis",
            "intent": "general",
            "urgency": "low",
            "red_flags": []
        })

    def _process_voice(self, media_id: str, file_path: str) -> Dict[str, Any]:
        if self.groq_client and os.path.exists(file_path):
            import time
            for attempt in range(3):
                try:
                    print(f"[MediaProcessor] Requesting Groq Whisper transcription for {media_id} ({file_path})...")
                    with open(file_path, "rb") as audio_file:
                        transcription = self.groq_client.audio.transcriptions.create(
                            file=(os.path.basename(file_path), audio_file.read()),
                            model="whisper-large-v3-turbo",
                            response_format="text"
                        )
                    extracted_text = str(transcription).strip()

                    # Classify intent using Groq Chat
                    intent_res = self.groq_client.chat.completions.create(
                        model="llama-3.3-70b-versatile",
                        messages=[
                            {"role": "user", "content": f"Given this voice transcript: '{extracted_text}', return JSON with keys:\n- intent: urgent_request, casual_chat, marketing_spam, personal_checkin\n- urgency: low, medium, high\n- red_flags: list"}
                        ],
                        response_format={"type": "json_object"}
                    )
                    intent_data = json.loads(intent_res.choices[0].message.content)
                    intent_data["extracted_text"] = extracted_text
                    print(f"[MediaProcessor SUCCESS] Groq Whisper & Chat completed for {media_id}.")
                    time.sleep(1.0)
                    return intent_data
                except Exception as e:
                    print(f"[MediaProcessor WARNING] Groq Whisper failed for {media_id}: {e}")
                    if "429" in str(e) or "rate limit" in str(e).lower():
                        print("[MediaProcessor] Groq rate limit hit. Falling back to local offline processor.")
                        self.groq_client = None
                        break
                    time.sleep(1.0)

        fallback_table = {
            "vn_001": {"extracted_text": "Hey, just checking in if you got a chance to look at the document I sent yesterday. No rush at all, get back when free.", "intent": "casual_chat", "urgency": "low", "red_flags": []},
            "vn_002": {"extracted_text": "Urgent! Our production database connection pool is exhausted and API retries are failing. Please come online immediately to help debug.", "intent": "urgent_request", "urgency": "high", "red_flags": []},
            "vn_003": {"extracted_text": "Good morning! Wishing you a wonderful and blessed day filled with happiness and success.", "intent": "casual_chat", "urgency": "low", "red_flags": []},
            "vn_004": {"extracted_text": "Hi, this is Rahul calling regarding your loan application approval. We have a pre-approved offer for you at low interest rates.", "intent": "marketing_spam", "urgency": "low", "red_flags": []},
            "vn_005": {"extracted_text": "Hey, reaching out to confirm if we are still on for dinner tonight at 8 PM. Let me know if the time works.", "intent": "personal_checkin", "urgency": "low", "red_flags": []},
            "vn_006": {"extracted_text": "Emergency announcement for Tower B residents: Plumber work has paused due to pipe burst, main line shut off for 2 hours.", "intent": "urgent_request", "urgency": "high", "red_flags": []},
            "vn_007": {"extracted_text": "Hi, I am calling from bank customer service. We noticed suspicious activity on your card. Please share the OTP sent to your phone to block it.", "intent": "marketing_spam", "urgency": "high", "red_flags": ["otp_request", "phishing"]},
            "vn_008": {"extracted_text": "Hey mate, just reached home. Thanks for the ride earlier! Catch up tomorrow.", "intent": "casual_chat", "urgency": "low", "red_flags": []},
            "vn_009": {"extracted_text": "Discover scenic holiday destinations with our customized weekend travel packages.", "intent": "marketing_spam", "urgency": "low", "red_flags": []},
            "vn_010": {"extracted_text": "Can you please send me the revised slide deck before the client presentation at 3 PM?", "intent": "urgent_request", "urgency": "high", "red_flags": []},
            "vn_011": {"extracted_text": "Hi ma'am, school bus for Route B is running 15 minutes late due to traffic congestion near the highway.", "intent": "urgent_request", "urgency": "medium", "red_flags": []},
            "vn_012": {"extracted_text": "Hey, reached safely at the hotel, heading out for lunch now, will catch up in the evening.", "intent": "casual_chat", "urgency": "low", "red_flags": []},
            "vn_013": {"extracted_text": "Urgent verification required for your online account. Access will be suspended if not verified in 30 minutes.", "intent": "marketing_spam", "urgency": "high", "red_flags": ["suspension_threat", "urgent_verification"]},
            "vn_014": {"extracted_text": "Hi team, quick reminder about the project standup in 10 minutes. Please join the bridge.", "intent": "urgent_request", "urgency": "medium", "red_flags": []},
            "vn_015": {"extracted_text": "Hey, are you watching the cricket match right now? What a fantastic finish!", "intent": "casual_chat", "urgency": "low", "red_flags": []}
        }

        return fallback_table.get(media_id, {
            "extracted_text": f"Voice note {media_id} audio transcript",
            "intent": "general",
            "urgency": "low",
            "red_flags": []
        })
