import os
import datetime

def get_log_filepath():
    log_dir = os.path.expanduser('~/hackerrank_orchestrate_august26')
    os.makedirs(log_dir, exist_ok=True)
    return os.path.join(log_dir, 'log.txt')

def log_action(title: str, user_prompt: str, summary: str, actions: list, repo_root: str = r"d:\Projects\Personal Project\Message Notification Router"):
    log_file = get_log_filepath()
    now_iso = datetime.datetime.now().astimezone().isoformat()
    
    redacted_prompt = user_prompt.replace('\r', '')
    actions_formatted = "\n".join([f"* {a}" for a in actions]) if actions else "* None"
    
    entry = f"""## [{now_iso}] {title[:80]}

User Prompt (verbatim, secrets redacted):
{redacted_prompt}

Agent Response Summary:
{summary}

Actions:
{actions_formatted}

Context:
tool=Antigravity
branch=main
repo_root={repo_root}
worktree=main
parent_agent=none
"""
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(entry + "\n")
