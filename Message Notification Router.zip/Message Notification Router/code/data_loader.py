import os
import pandas as pd
from typing import Dict, Any

class DataLoader:
    """
    Loads and indexes all dataset files into fast-access lookups and graph connections.
    """

    def __init__(self, dataset_dir: str = "dataset"):
        self.dataset_dir = dataset_dir
        self.users = {}
        self.groups = {}
        self.group_members = {}
        self.business_accounts = {}
        self.user_business_history = {}
        self.message_history = []
        self.message_events = {}
        self.images = {}
        self.voice_notes = {}
        self.daily_notification_summary = {}

        self._load_all()

    def _load_all(self):
        # 1. users.csv
        users_path = os.path.join(self.dataset_dir, "users.csv")
        if os.path.exists(users_path):
            df = pd.read_csv(users_path).fillna("")
            for _, row in df.iterrows():
                self.users[row["user_id"]] = row.to_dict()

        # 2. groups.csv
        groups_path = os.path.join(self.dataset_dir, "groups.csv")
        if os.path.exists(groups_path):
            df = pd.read_csv(groups_path).fillna("")
            for _, row in df.iterrows():
                self.groups[row["group_id"]] = row.to_dict()

        # 3. group_members.csv (key: (group_id, user_id))
        gm_path = os.path.join(self.dataset_dir, "group_members.csv")
        if os.path.exists(gm_path):
            df = pd.read_csv(gm_path).fillna("")
            for _, row in df.iterrows():
                key = (str(row["group_id"]), str(row["user_id"]))
                self.group_members[key] = row.to_dict()

        # 4. business_accounts.csv
        ba_path = os.path.join(self.dataset_dir, "business_accounts.csv")
        if os.path.exists(ba_path):
            df = pd.read_csv(ba_path).fillna("")
            for _, row in df.iterrows():
                self.business_accounts[row["business_id"]] = row.to_dict()

        # 5. user_business_history.csv (key: (user_id, business_id))
        ubh_path = os.path.join(self.dataset_dir, "user_business_history.csv")
        if os.path.exists(ubh_path):
            df = pd.read_csv(ubh_path).fillna("")
            for _, row in df.iterrows():
                key = (str(row["user_id"]), str(row["business_id"]))
                self.user_business_history[key] = row.to_dict()

        # 6. message_events.csv (key: message_id)
        me_path = os.path.join(self.dataset_dir, "message_events.csv")
        if os.path.exists(me_path):
            df = pd.read_csv(me_path).fillna("")
            for _, row in df.iterrows():
                self.message_events[row["message_id"]] = row.to_dict()

        # 7. message_history.csv
        mh_path = os.path.join(self.dataset_dir, "message_history.csv")
        if os.path.exists(mh_path):
            df = pd.read_csv(mh_path).fillna("")
            for _, row in df.iterrows():
                item = row.to_dict()
                # Join with event outcome if present
                msg_id = item["message_id"]
                if msg_id in self.message_events:
                    item["event"] = self.message_events[msg_id]
                else:
                    item["event"] = {}
                self.message_history.append(item)

        # 8. images.csv
        img_path = os.path.join(self.dataset_dir, "images.csv")
        if os.path.exists(img_path):
            df = pd.read_csv(img_path).fillna("")
            for _, row in df.iterrows():
                self.images[row["image_id"]] = row["file_path"]

        # 9. voice_notes.csv
        vn_path = os.path.join(self.dataset_dir, "voice_notes.csv")
        if os.path.exists(vn_path):
            df = pd.read_csv(vn_path).fillna("")
            for _, row in df.iterrows():
                self.voice_notes[row["voice_note_id"]] = row["file_path"]

        # 10. daily_notification_summary.csv (key: (user_id, date))
        dns_path = os.path.join(self.dataset_dir, "daily_notification_summary.csv")
        if os.path.exists(dns_path):
            df = pd.read_csv(dns_path).fillna("")
            for _, row in df.iterrows():
                key = (str(row["user_id"]), str(row["date"]))
                self.daily_notification_summary[key] = row.to_dict()

    def get_user(self, user_id: str) -> Dict[str, Any]:
        return self.users.get(str(user_id), {})

    def get_group(self, group_id: str) -> Dict[str, Any]:
        return self.groups.get(str(group_id), {})

    def get_group_member(self, group_id: str, user_id: str) -> Dict[str, Any]:
        return self.group_members.get((str(group_id), str(user_id)), {})

    def get_business(self, business_id: str) -> Dict[str, Any]:
        return self.business_accounts.get(str(business_id), {})

    def get_user_business_history(self, user_id: str, business_id: str) -> Dict[str, Any]:
        return self.user_business_history.get((str(user_id), str(business_id)), {})

    def get_image_path(self, image_id: str) -> str:
        rel_path = self.images.get(str(image_id), "")
        if rel_path:
            return os.path.join(self.dataset_dir, rel_path)
        return ""

    def get_voice_note_path(self, voice_note_id: str) -> str:
        rel_path = self.voice_notes.get(str(voice_note_id), "")
        if rel_path:
            return os.path.join(self.dataset_dir, rel_path)
        return ""

    def get_daily_summary(self, user_id: str, date_str: str) -> Dict[str, Any]:
        return self.daily_notification_summary.get((str(user_id), str(date_str)), {})
