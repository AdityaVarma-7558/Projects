import os
import sys
import pandas as pd

# Add code directory to Python path
sys.path.append(os.path.dirname(__file__))

from data_loader import DataLoader
from media_processor import MediaProcessor
from router import Router
from logger import log_action

def main():
    print("==========================================")
    print("WhatsApp Message Notification Router Pipeline")
    print("==========================================")

    dataset_dir = "dataset"
    messages_path = os.path.join(dataset_dir, "messages.csv")
    
    if not os.path.exists(messages_path):
        print(f"Error: {messages_path} not found!")
        sys.exit(1)

    print(f"1. Loading dataset context from '{dataset_dir}'...")
    dl = DataLoader(dataset_dir=dataset_dir)
    media_proc = MediaProcessor(cache_path="code/media_cache.json")
    router = Router(data_loader=dl, media_processor=media_proc)

    print(f"2. Reading incoming messages from '{messages_path}'...")
    messages_df = pd.read_csv(messages_path).fillna("")
    total_messages = len(messages_df)
    print(f"   Found {total_messages} incoming messages to route.")

    output_rows = []

    print("3. Processing messages through routing engine...")
    for idx, row in messages_df.iterrows():
        msg_dict = row.to_dict()
        pred = router.route_message(msg_dict)

        output_rows.append({
            "message_id": pred["message_id"],
            "action": pred["action"],
            "message_type": pred["message_type"],
            "reason": pred["reason"],
            "confidence": round(float(pred["confidence"]), 2),
            "evidence_message_ids": pred["evidence_message_ids"]
        })

        if (idx + 1) % 25 == 0 or (idx + 1) == total_messages:
            print(f"   Processed {idx + 1}/{total_messages} messages...")

    # Create output DataFrame with exact column order
    output_cols = ["message_id", "action", "message_type", "reason", "confidence", "evidence_message_ids"]
    output_df = pd.DataFrame(output_rows)[output_cols]

    # Save output to dataset/output.csv and root output.csv
    dataset_output_path = os.path.join(dataset_dir, "output.csv")
    root_output_path = "output.csv"

    output_df.to_csv(dataset_output_path, index=False)
    output_df.to_csv(root_output_path, index=False)

    print("\n4. Performing output validation checks...")
    assert len(output_df) == total_messages, f"Row count mismatch: expected {total_messages}, got {len(output_df)}"
    assert list(output_df.columns) == output_cols, f"Column mismatch: got {list(output_df.columns)}"
    assert not output_df.isnull().any().any(), "Output contains NaN values!"
    
    valid_actions = {"notify", "digest", "mute"}
    invalid_actions = set(output_df["action"]) - valid_actions
    assert not invalid_actions, f"Invalid actions found: {invalid_actions}"

    valid_types = {"personal", "urgent", "event", "payment", "business_update", "promotion", "greeting", "forward", "spam", "scam", "unknown"}
    invalid_types = set(output_df["message_type"]) - valid_types
    assert not invalid_types, f"Invalid message_types found: {invalid_types}"

    print("   [SUCCESS] All validation checks passed!")
    print(f"   Output saved to '{dataset_output_path}' and '{root_output_path}'.")

    # Log to AGENTS log file
    action_counts = output_df["action"].value_counts().to_dict()
    type_counts = output_df["message_type"].value_counts().to_dict()

    log_action(
        title="Generated Submission Predictions",
        user_prompt="Run full router pipeline on dataset/messages.csv and save output.csv",
        summary=f"Processed all {total_messages} incoming messages. Actions breakdown: {action_counts}. All contract validations passed.",
        actions=[
            f"Executed pipeline on dataset/messages.csv ({total_messages} rows)",
            f"Generated dataset/output.csv and root output.csv",
            f"Validated schema, row count, allowed values, and formatting"
        ]
    )

if __name__ == "__main__":
    main()
