import re
from typing import Dict, Any, List
from data_loader import DataLoader

def extract_tokens(text: str) -> set:
    if not text:
        return set()
    cleaned = re.sub(r'[^\w\s]', ' ', str(text).lower())
    return set(cleaned.split())

def compute_similarity(t1: str, t2: str) -> float:
    s1 = extract_tokens(t1)
    s2 = extract_tokens(t2)
    if not s1 or not s2:
        return 0.0
    intersection = s1.intersection(s2)
    union = s1.union(s2)
    return len(intersection) / float(len(union))

class EvidenceRetriever:
    def __init__(self, data_loader: DataLoader):
        self.dl = data_loader

    def retrieve_evidence(self, message: Dict[str, Any], signals: Dict[str, Any], media_info: Dict[str, Any] = None) -> List[str]:
        user_id = str(message.get("user_id", ""))
        conv_type = str(message.get("conversation_type", ""))
        group_id = str(message.get("group_id", ""))
        business_id = str(message.get("business_id", ""))
        sender_user_id = str(message.get("sender_user_id", ""))
        msg_text = str(message.get("message_text", ""))

        if media_info and media_info.get("extracted_text"):
            msg_text = (msg_text + " " + media_info.get("extracted_text", "")).strip()

        # If sender is completely new / no history for this user+context, return none
        if signals.get("hist_total", 0) == 0:
            return []

        # Filter candidates for same user and conversation context
        candidates = []
        for h in self.dl.message_history:
            if str(h.get("user_id")) != user_id:
                continue

            match = False
            if conv_type == "group" and group_id and str(h.get("group_id")) == group_id:
                match = True
            elif conv_type == "business" and business_id and str(h.get("business_id")) == business_id:
                match = True
            elif conv_type == "personal" and sender_user_id and str(h.get("sender_user_id")) == sender_user_id:
                match = True

            if match:
                candidates.append(h)

        if not candidates:
            return []

        # Score candidates based on text similarity and sender matching
        scored = []
        for c in candidates:
            c_text = str(c.get("message_text", ""))
            sim = compute_similarity(msg_text, c_text)

            # Sender boost if same sender_user_id in a group or personal chat
            sender_boost = 0.0
            if sender_user_id and str(c.get("sender_user_id")) == sender_user_id:
                sender_boost = 0.1

            score = sim + sender_boost
            scored.append((score, sim, str(c.get("message_id"))))

        scored.sort(key=lambda x: x[0], reverse=True)

        # Filter by threshold
        best_score, best_sim, best_id = scored[0]

        # If best similarity is very low and no exact sender match, return []
        if best_score < 0.05:
            return []

        selected = [best_id]

        # Check if second candidate is also strongly relevant (e.g. repeated viral forwards / promos)
        if len(scored) > 1:
            second_score, second_sim, second_id = scored[1]
            if second_score >= 0.8 * best_score and second_score > 0.12:
                selected.append(second_id)

        return selected

    def format_evidence_str(self, evidence_ids: List[str]) -> str:
        if not evidence_ids:
            return "none"
        return ";".join(evidence_ids)
